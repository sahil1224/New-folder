import React from "react"

import MultiStepForm from "../components/MultiStepForm"
import "../styles/MultiStepForm.css"


function Recycle() {
  return (
    <div className="dashboard-container">
          <MultiStepForm />
    </div>
      
    
  )
}

export default Recycle;

